    <?php get_header() ?>

    <?php get_template_part('template-parts/content' ,'latest' ) ?>

    <?php get_template_part('template-parts/cta/camp' ) ?>

    <?php get_template_part('template-parts/content' ,'news' ) ?>

    <?php get_template_part('template-parts/cta/conference','women' ) ?>

    <?php get_template_part('template-parts/content' ,'recipes' ) ?>

    <?php get_template_part('template-parts/cta/newsletter' ) ?>

    <?php get_template_part('template-parts/content' ,'shop' ) ?>

    <?php get_footer() ?>
