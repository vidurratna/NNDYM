<?php

?>

<?php get_template_part('template-parts/header/trending' ) ?>
<?php get_template_part('template-parts/header/middlebar' ) ?>
<?php get_template_part('template-parts/header/categories' ) ?>
