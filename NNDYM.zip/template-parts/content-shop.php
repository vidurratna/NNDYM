
    <div data-aos="fade-up" data-aos-duration="800" data-aos-once="true" class="bg-white w-11/12 m-auto p-8 mt-4 shadow sm:shadow-md md:shadow-lg lg:shadow-xl">
        <h1 class="text-3xl text-orange-600 uppercase font-bold">Get the merch</h1>
        <span class="block w-2/12 bg-orange-500 h-1"></span>
        <h1 class="text-4xl text-center my-32">Coming Soon!</h1>
    </div>