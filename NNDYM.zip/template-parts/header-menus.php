<?php?>
<?php get_template_part('template-parts/header/mobile' ) ?>
<?php get_template_part('template-parts/header/sidebar' ) ?>