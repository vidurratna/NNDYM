<?php get_header() ?>

<div data-aos="fade-up" data-aos-duration="800" data-aos-once="true" class=" h-64 my-40 flex justify-center items-center flex-col">
    <h1 class="text-6xl text-center">Those robotos missed places this page again!</h1>
    <a class="border-nndym-blue border-2 rounded-sm py-8 transition ease-in-out duration-300 px-24 my-4 uppercase font-bold text-nndym-blue hover:text-white hover:bg-nndym-blue" href="<?php echo get_home_url( ) ?>">Take me home please!</a>
</div>

<?php get_footer() ?>
